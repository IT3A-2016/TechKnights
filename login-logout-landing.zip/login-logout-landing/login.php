<?php
	session_start();
	include_once("db.php"); //Establishing connection with our database
	
	$error = ""; //Variable for storing our errors.
	if(isset($_POST["submit"]))
	{
		if(empty($_POST["studentnumber"]) || empty($_POST["password"]))
		{
			$error = "Both fields are required.";
		}else
		{
			// Define $studentnumber and $password
			$studentnumber=$_POST['studentnumber'];
			$password=$_POST['password'];

			// To protect from MySQL injection
			$studentnumber = stripslashes($studentnumber);
			$password = stripslashes($password);
			$studentnumber = mysqli_real_escape_string($connection, $studentnumber);
			$password = mysqli_real_escape_string($connection, $password);
			$password = md5($password);
			
			//Check studentnumber and password from database
			$sql="SELECT * FROM student WHERE studentnumber='$studentnumber' and password='$password'";
			$result=mysqli_query($connection,$sql);
			$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
			
			
			
			if(mysqli_num_rows($result) == 1)
			{
				$_SESSION['studentnumber'] = $studentnumber; // Initializing Session
				header("location: dash.php"); // Redirecting To Other Page
			}else
			{
				$error = "Incorrect studentnumber or password.";
			}

		}
	}

?>