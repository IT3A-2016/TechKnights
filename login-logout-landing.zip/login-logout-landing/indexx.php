<?php
	session_start();
	include_once 'db.php';

	if(isset($_POST['submit'])){
		$studentnumber=mysqli_real_escape_string($connection, $_POST['studentnumber']);
		$password=mysqli_real_escape_string($connection, $_POST['password']);
		$result=mysqli_query($connection, "SELECT * FROM student WHERE studentnumber='".$studentnumber."' and password='".$password."'");

		if($row=mysqli_fetch_array($result)){
			$_SESSION['student_id']=$row['student_id'];
			header('location: dash.php');
		}
		else{
			$note='';
		}
	}
?>


<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Login | Student</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">
  
  
</head>

  <body>
	<div class="login">
	<div><center><img src="logo.png" style="width:95%; height:75%; margin-top:5px;"></a></center></div>
<br>
					
<div class="container" style="margin-top: 35px">

    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <span class="glyphicon glyphicon-lock"></span> Login</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <div class="form-group">
                        <label for="studentnumber" class="col-sm-3 control-label">
                          StudentNumber</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control"  id="studentnumber" name="studentnumber" placeholder="StudentNumber" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-sm-3 control-label">
                            Password</label>
                        <div class="col-sm-9">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                        </div>
					<br><br>
					<div class="error" style="margin-left: 55px; margin-top: 20px; color: red"><?php echo $error;?></div>
					
                    </div>
        
                    <div class="form-group last">
                        <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-success btn-sm" value="Login" name="submit">
                                Sign in</button>
                                 <button type="reset" class="btn btn-default btn-sm">
                                Reset</button>
                        </div>
                    </div>
                    </form>
                </div>
               
            </div>
        </div>
    </div>
</div>

</body>
</html>
