<?php
include_once('db.php');
session_start();
$user_check=$_SESSION['studentnumber'];

$ses_sql = mysqli_query($connection,"SELECT studentnumber FROM student WHERE studentnumber='$user_check' ");

$row=mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);

$login_user=$row['studentnumber'];

if(!isset($user_check))
{
header("Location: index.php");
}
?>