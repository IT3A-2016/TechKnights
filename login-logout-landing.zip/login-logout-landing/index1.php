




<?php

	//encode sales -> insert into encodesales , update  branch inventory
	//encode trans -> insert into encode trans
	//submit order -> chec
	//receive order
	//dispatch

	include('login1.php'); // Include Login Script

	if ((isset($_SESSION['username']) != '')) 
	{
		header('Location: ho-dash.php');
	}	
?>

<!doctype html>
<html>

<head>

  <title>Lolet Bakeshop | Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <link href="http://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="http://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


<style>
body { 
  background: url(rr.jpg) fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

.panel-default {
opacity: 0.9;
margin-top:30px;
}
.form-group.last { margin-bottom:0px; }

</style>

			<link rel="shortcut icon" href="hcalogo.png">
</head>

<body>



<br>
<br>
<br>
<br>

<center><h1 style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif; font-size:35px; color: white; margin-bottom: 5px">Lolet Bakeshop | Headquarters</h1></center>
						<div class="col-sm-3">&nbsp;</div>
						<div class="col-sm-6"><hr></div>
						
<div class="container" style="margin-top: 35px">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <span class="glyphicon glyphicon-lock"></span> Login</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="post" action="">
                    <div class="form-group">
                        <label for="username" class="col-sm-3 control-label">
                          Username</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control"  id="username" name="username" placeholder="Username" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-sm-3 control-label">
                            Password</label>
                        <div class="col-sm-9">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                        </div>
					<br><br>
					<div class="error" style="margin-left: 55px; margin-top: 20px; color: red"><?php echo $error;?></div>
					
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox"/>
                                    Remember me
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group last">
                        <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-success btn-sm" value="Login" name="submit">
                                Sign in</button>
                                 <button type="reset" class="btn btn-default btn-sm">
                                Reset</button>
                        </div>
                    </div>
                    </form>
                </div>
               
            </div>
        </div>
    </div>
</div>
</body>
</html>