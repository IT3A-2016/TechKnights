<?php
	date_default_timezone_set("Asia/Hong_Kong");
	$connection=mysqli_connect("localhost", "root", "", "slss") or die("Couldn't connect to the database!" . mysql_error($connection));
		
?>